function DarkMode(){
    document.body.style.backgroundColor="#121212";
    document.body.style.color="white"
}
function Reset(){
    document.body.style.backgroundColor="grey";
    document.body.style.color="white"
}
let numberOfItems = 0;
function BasketPopup(){
    numberOfItems+=1;
    alert("Jeans Added To Basket!");
    alert("Number Of Jeans In Basket: " + numberOfItems);
    console.log("No Errors Detected.");
}
function purchaseFromBasket(){
    let userConfirmation = confirm("To confirm, you wish to purchase the items in your basket?");
    if(numberOfItems === 0){
        alert("Your Basket Is Empty.")
    }
    else{
    if(userConfirmation === true){
        alert("Your Total Is £" + total + ".00. " + "Thank You For Purchasing, We Hope You Enjoy Your Product(s).")
        numberOfItems = 0;
        total = 0;
        console.log("Basket Emptied.")
    }
    else{
        alert("Purchase Cancelled");
    }
}
}
let total = 0;
function addTotalJeans1(){
    total+=34
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalJeans2(){
    total+=28
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalJeans3(){
    total+=24
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalJeans4(){
    total+=26
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}