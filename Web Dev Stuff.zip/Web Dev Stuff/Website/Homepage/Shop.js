//Dark Mode & Reset Back To Normal
function DarkMode(){
    document.body.style.backgroundColor="#121212";
    document.body.style.color="white"
}
function Reset(){
    document.body.style.backgroundColor="grey";
    document.body.style.color="white"
}
//Automatic Slideshow
function changeImg(){
    document.slide.src = images[count];
    if(count < images.length-1){
        count++;
    }
    else{
        count=0;
    }
    setTimeout("changeImg()", time);
}
function next(){
    count=count++;
    document.slide.src=images[count];

    if(count < images.length - 1){
        count++;
    }
    else{
        count=0;
    }
}
function previous(){
    count=count--;
    document.slide.src=images[count];
    if(count < images.length-1){
        count++;
    }
    else{
        count=0;
    }
}
window.onload=changeImg;
var count = 0;
var images = [];
var time = 1500;

images[0] = "Hoodies/hoodies/hoodie1.png";
images[1] = "Hoodies/hoodies/hoodie2.png";
images[2] = "Hoodies/hoodies/hoodie3.png";
images[3] = "Hoodies/hoodies/hoodie4.png";
images[4] = "Jeans/jeans/jeans1.png"
images[5] = "Jeans/jeans/jeans2.png"
images[6] = "Jeans/jeans/jeans3.png"
images[7] = "Jeans/jeans/jeans4.png"
images[8] = "Shoes/shoes/shoes1.png"
images[9] = "Shoes/shoes/shoes2.png"
images[10] = "Shoes/shoes/shoes3.png"
images[11] = "Shoes/shoes/shoes4.png"
