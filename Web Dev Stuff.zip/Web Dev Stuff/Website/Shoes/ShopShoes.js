function DarkMode(){
    document.body.style.backgroundColor="#121212";
    document.body.style.color="white";
}
function Reset(){
    document.body.style.backgroundColor="grey";
    document.body.style.color="white";
}
let numberOfItems = 0;
function BasketPopup(){
    numberOfItems+=1;
    alert("Shoes Added To Basket!");
    alert("Number Of Shoes In Basket: " + numberOfItems);
    console.log("No Errors Detected.");
}
function purchaseFromBasket(){
    let userConfirmation = confirm("To confirm, you wish to purchase the items in your basket?");
    if(numberOfItems === 0){
        alert("Your Basket Is Empty.")
    }
    else{
    if(userConfirmation === true){
        alert("Your Total Is £" + total + ".00. " + "Thank You For Purchasing, We Hope You Enjoy Your Product(s).")
        numberOfItems = 0;
        total = 0;
        console.log("Basket Emptied.")
    }
    else{
        alert("Purchase Cancelled");
    }
}
}
let total = 0;
function addTotalShoes1(){
    total+=23
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalShoes2(){
    total+=21
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalShoes3(){
    total+=25
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalShoes4(){
    total+=20
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}