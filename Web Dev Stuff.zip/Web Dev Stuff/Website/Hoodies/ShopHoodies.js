function DarkMode(){
    document.body.style.backgroundColor="#121212";
    document.body.style.color="white"
}
function Reset(){
    document.body.style.backgroundColor="grey";
    document.body.style.color="white"
}
let numberOfItems = 0;
function BasketPopup(){
    numberOfItems+=1;
    alert("Hoodie Added To Basket!");
    alert("Number Of Hoodies In Basket: " + numberOfItems);
}
function purchaseFromBasket(){
    let userConfirmation = confirm("To confirm, you wish to purchase the items in your basket?");
    if(numberOfItems === 0){
        alert("Your Basket Is Empty.")
    }
    else{
    if(userConfirmation === true){
        alert("Your Total Is £" + total + ".00. " + "Thank You For Purchasing, We Hope You Enjoy Your Product(s).")
        numberOfItems = 0;
        total = 0;
        console.log("Basket Emptied.")
    }
    else{
        alert("Purchase Cancelled");
    }
}
}
let total = 0;
function addTotalHoodies1(){
    total+=28
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalHoodies2(){
    total+=31
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalHoodies3(){
    total+=27
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}
function addTotalHoodies4(){
    total+=32
    alert("Total Cost Of Items In Basket: £" + total + ".00")
}